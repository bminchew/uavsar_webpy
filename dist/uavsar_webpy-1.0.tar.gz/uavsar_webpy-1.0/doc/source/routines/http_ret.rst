.. highlight:: rst
.. _http_retrieve:

**http_retrieve.py**
--------------------
.. automodule:: http_retrieve
   :members:
